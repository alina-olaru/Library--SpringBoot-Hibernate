package com.alina.mylibrary;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MylibraryApplicationTests {

	@Test
	void contextLoads() {
	}

}
